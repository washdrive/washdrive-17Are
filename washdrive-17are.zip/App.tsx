import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Settings, Truck, Loader2, Phone, MessageCircle, Star, Zap, 
  Globe, Bell, LogOut, ChevronRight, User as UserIcon, MapPin, Camera, X, Check,
  Navigation as NavIcon, History, Ruler, Moon, Info, FileText, Shield, Edit3, CheckCircle2
} from 'lucide-react';
import { Logo } from './components/Logo';
import { MapBackground } from './components/MapBackground';
import { TRANSLATIONS, COUNTRIES, ALL_LANGUAGES } from './constants';
import { Language, UserRole, ServiceType, WasherOffer, ServiceRequest, CountryCode } from './types';

const App = () => {
  const [lang, setLang] = useState<string>('fr');
  const [view, setView] = useState<'intro' | 'role' | 'auth' | 'main' | 'settings'>('intro');
  const [settingsSubView, setSettingsSubView] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number; accuracy?: number } | null>(null);
  const [isGpsReady, setIsGpsReady] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [distanceUnit, setDistanceUnit] = useState('km');
  
  // Registration State
  const [country, setCountry] = useState<CountryCode>(COUNTRIES[0]);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [vehicle, setVehicle] = useState<'moto_coffre' | 'van_wash'>('van_wash');
  const [error, setError] = useState('');

  // Service States
  const [priceOffer, setPriceOffer] = useState(70);
  const [activeRequest, setActiveRequest] = useState<ServiceRequest | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [rating, setRating] = useState(5);

  const t = TRANSLATIONS[lang] || TRANSLATIONS['fr'];

  useEffect(() => {
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        setUserLocation({ 
          lat: pos.coords.latitude, 
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy 
        });
        setIsGpsReady(true);
      },
      (err) => {
        console.warn("GPS Access Error:", err);
        if (!userLocation) setUserLocation({ lat: 33.5883, lng: -7.6114, accuracy: 50 });
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  const handleRegister = () => {
    if (!name.trim() || !phone.trim() || !country || (userRole === 'washer' && !vehicle)) {
      setError(t.mandatoryFields);
      return;
    }
    setError('');
    setView('main');
  };

  const handleDeclineOffer = (offerId: string) => {
    if (!activeRequest) return;
    const newOffers = activeRequest.offers.filter(o => o.id !== offerId);
    if (newOffers.length === 0) setActiveRequest(null);
    else setActiveRequest({ ...activeRequest, offers: newOffers });
  };

  const handleAcceptOffer = (offer: WasherOffer) => {
    setActiveRequest(prev => prev ? { ...prev, status: 'accepted' } : null);
    setTimeout(() => {
      setActiveRequest(prev => prev ? { ...prev, status: 'in_progress' } : null);
    }, 2500);
  };

  const finishService = () => {
    setActiveRequest(prev => prev ? { ...prev, status: 'rating' } : null);
  };

  const renderSettingsSubView = () => {
    const close = () => setSettingsSubView(null);
    let title = "";
    let content = null;

    switch(settingsSubView) {
      case 'history':
        title = t.history;
        content = <div className="p-8 text-center text-slate-400">{t.noHistory}</div>;
        break;
      case 'language':
        title = t.selectLanguage;
        content = (
          <div className="flex flex-col bg-white">
            {ALL_LANGUAGES.map((l) => (
              <button 
                key={l.code}
                onClick={() => { setLang(l.code); close(); }}
                className={`flex items-center justify-between px-6 py-5 border-b border-slate-50 active:bg-slate-50 ${lang === l.code ? 'bg-blue-50/10' : ''}`}
              >
                <div className="flex items-center gap-4">
                  <span className="text-2xl">{l.flag || '🌐'}</span>
                  <div className="flex flex-col items-start">
                    <span className={`text-lg font-bold ${lang === l.code ? 'text-blue-600' : 'text-blue-950'}`}>{l.name}</span>
                    <span className="text-xs text-slate-400 font-medium uppercase">{l.code}</span>
                  </div>
                </div>
                {lang === l.code && <CheckCircle2 className="text-blue-600" size={24} />}
              </button>
            ))}
          </div>
        );
        break;
      case 'about':
        title = t.aboutApp;
        content = <div className="p-8 space-y-4 text-slate-500 font-medium leading-relaxed">
          <Logo size={40} className="mb-6" />
          <p className="font-bold text-blue-900">{t.appVersion}</p>
          <p>{t.appDesc}</p>
          <p>{t.appCopyright}</p>
          <p className="pt-4 text-sm opacity-60 italic border-t border-slate-100">{t.appTagline}</p>
        </div>;
        break;
      case 'rules':
        title = t.rules;
        content = <div className="p-8 text-slate-500 space-y-6">
          <div>
            <p className="font-black text-blue-950 text-sm uppercase tracking-widest mb-2">01. {t.priceOffer}</p>
            <p>Les prix sont négociés de gré à gré directement sur l'application.</p>
          </div>
          <div>
            <p className="font-black text-blue-950 text-sm uppercase tracking-widest mb-2">02. Respect</p>
            <p>Toute forme d'impolitesse entraînera un bannissement immédiat.</p>
          </div>
          <div>
            <p className="font-black text-blue-950 text-sm uppercase tracking-widest mb-2">03. GPS</p>
            <p>Votre position GPS doit être active pour garantir la mise en relation.</p>
          </div>
        </div>;
        break;
      case 'privacy':
        title = t.privacy;
        content = <div className="p-8 text-slate-500 space-y-4 leading-relaxed">
          <p className="font-bold text-blue-900">Données sécurisées</p>
          <p>WashDrive utilise le cryptage de bout en bout pour protéger vos informations personnelles.</p>
          <p>Votre géolocalisation n'est stockée que pendant la durée de la prestation de lavage.</p>
        </div>;
        break;
    }

    return (
      <div className={`absolute inset-0 z-[300] animate-in slide-in-from-right flex flex-col ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
        <div className={`flex items-center px-4 h-16 shrink-0 border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-100'}`}>
          <button onClick={close} className="p-2 -ml-2 rounded-full active:bg-slate-100">
            <ArrowLeft size={24} className={isDarkMode ? 'text-white' : 'text-slate-800'} />
          </button>
          <h1 className={`ml-4 text-xl font-black ${isDarkMode ? 'text-white' : 'text-blue-950'}`}>{title}</h1>
        </div>
        <div className="flex-1 overflow-y-auto no-scrollbar">{content}</div>
      </div>
    );
  };

  return (
    <div className={`h-screen w-screen flex flex-col relative overflow-hidden transition-colors duration-300 ${isDarkMode ? 'bg-slate-900' : 'bg-slate-50'}`}>
       <MapBackground showWashers={view === 'main'} userLocation={userLocation} language={lang} />
       
       {/* INTRO - Entièrement traduit */}
       {view === 'intro' && (
         <div className="absolute inset-0 z-[200] bg-yellow-400 flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-700">
            <div className="animate-float mb-8"><Logo size={70} /></div>
            <h2 className="text-4xl font-black text-blue-900 mb-4 leading-tight">{t.introSlide1Title}</h2>
            <p className="text-blue-900/70 font-bold mb-12 text-lg px-4">{t.introSlide1Desc}</p>
            <button onClick={() => setView('role')} className="w-full max-w-sm bg-blue-900 text-white font-black py-6 rounded-[32px] text-xl shadow-2xl active:scale-95 transition-all transform hover:-translate-y-1">{t.getStarted}</button>
         </div>
       )}

       {/* ROLE SELECTION - Entièrement traduit */}
       {view === 'role' && (
         <div className={`absolute inset-0 z-[200] flex flex-col p-8 items-center justify-center ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
            <h2 className={`text-3xl font-black mb-12 text-center px-6 ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{t.whoAreYou}</h2>
            <div className="w-full max-w-md space-y-5">
               <button onClick={() => { setUserRole('client'); setView('auth'); }} className={`w-full p-8 rounded-[40px] border-2 flex items-center gap-6 hover:border-blue-900 transition-all text-left group ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
                  <div className="w-16 h-16 bg-blue-100 rounded-3xl flex items-center justify-center text-blue-900 shadow-inner group-hover:bg-blue-900 group-hover:text-white transition-all"><UserIcon size={32} /></div>
                  <div><h3 className={`font-black text-xl ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{t.imClient}</h3><p className="text-slate-400 font-bold">{t.clientDesc}</p></div>
               </button>
               <button onClick={() => { setUserRole('washer'); setView('auth'); }} className={`w-full p-8 rounded-[40px] border-2 flex items-center gap-6 hover:border-blue-900 transition-all text-left group ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
                  <div className="w-16 h-16 bg-yellow-100 rounded-3xl flex items-center justify-center text-blue-900 shadow-inner group-hover:bg-blue-900 group-hover:text-white transition-all"><Truck size={32} /></div>
                  <div><h3 className={`font-black text-xl ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{t.imWasher}</h3><p className="text-slate-400 font-bold">{t.washerDesc}</p></div>
               </button>
            </div>
         </div>
       )}

       {/* AUTH / REGISTER - Entièrement traduit */}
       {view === 'auth' && (
         <div className={`absolute inset-0 z-[200] flex flex-col p-8 animate-in slide-in-from-right ${isDarkMode ? 'bg-slate-900' : 'bg-white'}`}>
            <button onClick={() => setView('role')} className={`mb-8 p-4 w-fit rounded-full active:scale-90 transition-all ${isDarkMode ? 'bg-slate-800 text-white' : 'bg-slate-100 text-blue-900'}`}><ArrowLeft size={24} /></button>
            <h2 className={`text-4xl font-black mb-2 ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{t.register}</h2>
            <p className="text-slate-400 font-black mb-10 text-lg uppercase tracking-widest">{userRole === 'client' ? t.profileClient : t.profileWasher}</p>
            <div className="space-y-6 w-full max-w-md mx-auto no-scrollbar overflow-y-auto pb-10">
               <div className="space-y-2">
                 <label className="text-xs font-black text-blue-900/40 uppercase tracking-widest pl-1">{t.fullName} *</label>
                 <input value={name} onChange={e => setName(e.target.value)} type="text" placeholder="Ex: Ahmed Alaoui" className={`w-full p-6 rounded-3xl border-2 font-bold outline-none focus:border-blue-900 text-lg ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-100'}`} />
               </div>
               <div className="space-y-2">
                  <label className="text-xs font-black text-blue-900/40 uppercase tracking-widest pl-1">{t.phoneNumber} *</label>
                  <div className="flex gap-3">
                    <div className="relative">
                      <select value={country.code} onChange={e => setCountry(COUNTRIES.find(c => c.code === e.target.value) || country)} className={`appearance-none p-6 pr-12 rounded-3xl border-2 font-black outline-none focus:border-blue-900 text-lg ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-100'}`}>
                         {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.flag} {c.dialCode}</option>)}
                      </select>
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">▼</div>
                    </div>
                    <input value={phone} onChange={e => setPhone(e.target.value)} type="tel" placeholder="06 12 34 56 78" className={`flex-1 p-6 rounded-3xl border-2 font-bold outline-none focus:border-blue-900 text-lg ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-100'}`} />
                  </div>
               </div>
               <button onClick={handleRegister} className="w-full py-6 bg-yellow-400 text-blue-900 font-black rounded-3xl shadow-2xl active:scale-95 transition-all text-xl mt-4">{t.confirmRegistration}</button>
            </div>
         </div>
       )}

       {/* SETTINGS VIEW - Entièrement traduit */}
       {view === 'settings' && (
         <div className={`absolute inset-0 z-[250] flex flex-col animate-in slide-in-from-left h-full ${isDarkMode ? 'bg-slate-900' : 'bg-[#F9FAFB]'}`}>
            {settingsSubView && renderSettingsSubView()}
            
            <div className={`flex items-center px-4 h-16 shrink-0 ${isDarkMode ? 'bg-slate-900' : 'bg-white border-b border-slate-100'}`}>
              <button onClick={() => setView('main')} className="p-2 -ml-2 rounded-full active:bg-slate-100">
                <ArrowLeft size={24} className={isDarkMode ? 'text-white' : 'text-slate-800'} />
              </button>
              <h1 className={`ml-4 text-xl font-black ${isDarkMode ? 'text-white' : 'text-blue-950'}`}>{t.settings}</h1>
            </div>

            <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-6">
              <div className={`p-6 rounded-[32px] shadow-sm flex items-center justify-between ${isDarkMode ? 'bg-slate-800' : 'bg-white'}`}>
                <div className="flex items-center gap-4">
                  <div className={`w-20 h-20 rounded-full flex items-center justify-center border-4 border-slate-100 ${isDarkMode ? 'bg-slate-700 border-slate-600' : 'bg-slate-50'}`}>
                    <UserIcon size={40} className="text-slate-300" />
                  </div>
                  <div className="flex flex-col">
                    <span className={`text-xl font-black ${isDarkMode ? 'text-white' : 'text-blue-950'}`}>{name || 'Ahmed Alaoui'}</span>
                    <span className="text-slate-400 font-black text-sm uppercase tracking-tighter">{country.dialCode} {phone || '661 23 45 67'}</span>
                  </div>
                </div>
                <button className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><Edit3 size={20} /></button>
              </div>

              <div className="space-y-2">
                <h3 className="text-[12px] font-black text-slate-400 uppercase tracking-widest px-3 mb-3">{t.general}</h3>
                <div className={`rounded-[32px] overflow-hidden shadow-sm ${isDarkMode ? 'bg-slate-800' : 'bg-white'}`}>
                  <div onClick={() => setSettingsSubView('history')} className="flex items-center px-6 py-5 active:bg-slate-50 cursor-pointer transition-colors">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><History size={24} /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.history}</span>
                    <ChevronRight size={18} className="text-slate-300" />
                  </div>
                  <div className={`h-px mx-6 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-50'}`}></div>
                  
                  <div onClick={() => setSettingsSubView('language')} className="flex items-center px-6 py-5 active:bg-slate-50 cursor-pointer transition-colors">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><Globe size={24} /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.languages}</span>
                    <div className="flex items-center gap-3">
                      <div className={`flex items-center gap-2 p-1.5 px-3 rounded-2xl ${isDarkMode ? 'bg-slate-700' : 'bg-slate-100'}`}>
                        <span className="text-sm font-black text-blue-600 uppercase tracking-widest">{lang}</span>
                        <ChevronRight size={16} className="text-slate-300" />
                      </div>
                    </div>
                  </div>
                  <div className={`h-px mx-6 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-50'}`}></div>

                  <div className="flex items-center px-6 py-5">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><Bell size={24} /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.notifications}</span>
                    <button 
                      onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                      className={`w-14 h-8 rounded-full relative transition-all duration-300 shadow-inner ${notificationsEnabled ? 'bg-green-500' : 'bg-slate-200'}`}
                    >
                      <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all duration-300 ${notificationsEnabled ? 'left-7' : 'left-1'}`}></div>
                    </button>
                  </div>
                  <div className={`h-px mx-6 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-50'}`}></div>

                  <div className="flex items-center px-6 py-5">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><Ruler size={24} className="-rotate-45" /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.distanceUnit}</span>
                    <button onClick={() => setDistanceUnit(u => u === 'km' ? 'mi' : 'km')} className="p-2 px-4 rounded-2xl bg-slate-50 text-blue-900 font-black text-sm shadow-sm">
                      {distanceUnit === 'km' ? 'KM' : 'MI'}
                    </button>
                  </div>
                  <div className={`h-px mx-6 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-50'}`}></div>

                  <div className="flex items-center px-6 py-5">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><Moon size={24} /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.darkMode}</span>
                    <button 
                      onClick={() => setIsDarkMode(!isDarkMode)}
                      className={`w-14 h-8 rounded-full relative transition-all duration-300 shadow-inner ${isDarkMode ? 'bg-blue-600' : 'bg-slate-200'}`}
                    >
                      <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all duration-300 ${isDarkMode ? 'left-7' : 'left-1'}`}></div>
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-[12px] font-black text-slate-400 uppercase tracking-widest px-3 mb-3">{t.about}</h3>
                <div className={`rounded-[32px] overflow-hidden shadow-sm ${isDarkMode ? 'bg-slate-800' : 'bg-white'}`}>
                  <div onClick={() => setSettingsSubView('about')} className="flex items-center px-6 py-5 active:bg-slate-50 cursor-pointer">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><Info size={24} /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.aboutApp}</span>
                    <ChevronRight size={18} className="text-slate-300" />
                  </div>
                  <div className={`h-px mx-6 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-50'}`}></div>
                  <div onClick={() => setSettingsSubView('rules')} className="flex items-center px-6 py-5 active:bg-slate-50 cursor-pointer">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><FileText size={24} /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.rules}</span>
                    <ChevronRight size={18} className="text-slate-300" />
                  </div>
                  <div className={`h-px mx-6 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-50'}`}></div>
                  <div onClick={() => setSettingsSubView('privacy')} className="flex items-center px-6 py-5 active:bg-slate-50 cursor-pointer">
                    <div className="w-10 h-10 flex items-center justify-center text-slate-400"><Shield size={24} /></div>
                    <span className={`flex-1 ml-4 font-bold ${isDarkMode ? 'text-slate-200' : 'text-blue-950'}`}>{t.privacy}</span>
                    <ChevronRight size={18} className="text-slate-300" />
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setView('role')}
                className="w-full p-6 mt-6 rounded-[32px] font-black flex items-center justify-center gap-4 text-red-500 bg-red-50 active:scale-95 transition-all shadow-sm"
              >
                <LogOut size={24} /> {t.logout}
              </button>
              
              <div className="text-center pt-4 pb-10">
                 <p className="text-slate-300 font-black text-xs uppercase tracking-[0.2em]">{t.appVersion}</p>
              </div>
            </div>
         </div>
       )}

       {/* MAIN INTERFACE - Dynamiquement traduit */}
       {view === 'main' && (
         <div className="absolute inset-0 z-10 flex flex-col pointer-events-none">
            {/* TOP BAR */}
            <div className="p-4 flex justify-between pointer-events-auto">
               <button onClick={() => setView('settings')} className={`p-5 rounded-[24px] shadow-2xl border active:scale-90 transition-all ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'}`}><Settings size={24} className={isDarkMode ? 'text-white' : 'text-blue-900'} /></button>
               <div className={`px-6 py-4 rounded-[24px] shadow-2xl border font-black flex items-center gap-4 ${isDarkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-100 text-blue-900'}`}>
                  <div className={`w-3 h-3 rounded-full ${isGpsReady ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                  <span className="text-sm tracking-tight uppercase">{isGpsReady ? 'Live GPS' : t.gpsOffline}</span>
                  <div className="w-px h-5 bg-slate-200"></div>
                  <span className="text-lg">{country.currency}</span>
               </div>
            </div>

            {/* NEGO PANEL */}
            {userRole === 'client' && !activeRequest && (
              <div className="mt-auto p-4 pb-12 pointer-events-auto animate-in slide-in-from-bottom duration-500">
                 <div className={`p-10 rounded-[48px] shadow-2xl border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'}`}>
                    <div className="flex items-center justify-between mb-10">
                       <div className="flex flex-col">
                          <span className="text-[12px] font-black text-slate-300 uppercase tracking-widest pl-1">{t.priceOffer}</span>
                          <div className={`text-6xl font-black ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{priceOffer} <span className="text-2xl opacity-30">{country.currency}</span></div>
                       </div>
                       <div className="flex gap-4">
                          <button onClick={() => setPriceOffer(p => Math.max(20, p - 5))} className={`w-16 h-16 rounded-[24px] flex items-center justify-center font-black text-4xl shadow-inner ${isDarkMode ? 'bg-slate-700 text-white' : 'bg-slate-100 text-blue-900'}`}>-</button>
                          <button onClick={() => setPriceOffer(p => p + 5)} className={`w-16 h-16 rounded-[24px] flex items-center justify-center font-black text-4xl shadow-inner ${isDarkMode ? 'bg-slate-700 text-white' : 'bg-slate-100 text-blue-900'}`}>+</button>
                       </div>
                    </div>
                    <button onClick={() => {
                      setIsSearching(true);
                      setTimeout(() => {
                        setIsSearching(false);
                        setActiveRequest({
                          id: 'req1', clientName: name || 'Ahmed', pickupLocation: 'Ici', coordinates: userLocation!, priceOffer, serviceType: 'complete', status: 'negotiating',
                          offers: [
                            { id: 'o1', washerName: 'Elite Wash Van', rating: 4.9, price: priceOffer + 15, distance: '0.7', eta: '4', vehicleType: 'van_wash' },
                            { id: 'o2', washerName: 'Moto Wash Fast', rating: 4.8, price: priceOffer, distance: '1.1', eta: '8', vehicleType: 'moto_coffre' }
                          ]
                        });
                      }, 2000);
                    }} className="w-full py-7 bg-blue-900 text-white font-black rounded-[32px] text-2xl shadow-2xl active:scale-95 transition-all">
                       {isSearching ? <div className="flex items-center justify-center gap-4"><Loader2 className="animate-spin" size={28} /> <span>{t.searching}</span></div> : t.submitRequest}
                    </button>
                 </div>
              </div>
            )}

            {/* OFFERS VIEW */}
            {activeRequest?.status === 'negotiating' && (
              <div className="mt-auto p-4 pb-12 pointer-events-auto h-[65vh] overflow-y-auto no-scrollbar">
                 <div className="flex flex-col gap-5">
                    {activeRequest.offers.map(offer => (
                      <div key={offer.id} className={`p-8 rounded-[48px] shadow-2xl border animate-in slide-in-from-right ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'}`}>
                         <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-6">
                               <div className="w-20 h-20 bg-yellow-400 rounded-[24px] flex items-center justify-center text-blue-900 shadow-xl">{offer.vehicleType === 'van_wash' ? <Truck size={40} /> : <Zap size={40} />}</div>
                               <div>
                                  <h4 className={`font-black text-2xl ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{offer.washerName}</h4>
                                  <div className="flex items-center text-yellow-500 font-black text-md gap-2"><Star size={20} fill="currentColor" /> {offer.rating} <span className="text-slate-300 mx-1">•</span> <span className="text-slate-400">{offer.distance} km</span></div>
                               </div>
                            </div>
                            <div className="text-right">
                               <div className={`text-3xl font-black ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{offer.price} {country.currency}</div>
                               <div className="text-xs font-black text-slate-300 uppercase tracking-widest">{offer.eta} min</div>
                            </div>
                         </div>
                         <div className="grid grid-cols-2 gap-5">
                            <button onClick={() => handleDeclineOffer(offer.id)} className="py-6 bg-red-50 text-red-500 font-black rounded-[28px] text-lg active:scale-95 transition-all">{t.decline}</button>
                            <button onClick={() => handleAcceptOffer(offer)} className="py-6 bg-blue-900 text-white font-black rounded-[28px] text-lg active:scale-95 transition-all shadow-xl">{t.accept}</button>
                         </div>
                      </div>
                    ))}
                 </div>
              </div>
            )}

            {activeRequest?.status === 'in_progress' && (
              <div className="mt-auto p-4 pb-12 pointer-events-auto animate-in slide-in-from-bottom">
                 <div className={`p-12 rounded-[48px] shadow-2xl border flex flex-col items-center ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'}`}>
                    <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center mb-8 relative">
                       <Loader2 className="w-16 h-16 text-blue-900 animate-spin" />
                       <div className="absolute -top-2 -right-2 w-10 h-10 bg-yellow-400 rounded-2xl flex items-center justify-center shadow-lg"><Truck size={20} className="text-blue-900" /></div>
                    </div>
                    <h3 className={`text-4xl font-black mb-4 text-center ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{t.washInProgress}</h3>
                    <p className="text-slate-400 font-bold mb-12 text-center text-lg">{t.driverEnRoute}</p>
                    <button onClick={finishService} className="w-full py-7 bg-yellow-400 text-blue-900 font-black rounded-[32px] text-2xl shadow-xl active:scale-95 transition-all">{t.confirmEnd}</button>
                 </div>
              </div>
            )}

            {activeRequest?.status === 'rating' && (
              <div className={`absolute inset-0 z-[150] backdrop-blur-3xl flex flex-col items-center justify-center p-12 pointer-events-auto text-center animate-in zoom-in duration-500 ${isDarkMode ? 'bg-slate-900/95' : 'bg-white/95'}`}>
                 <div className="w-40 h-40 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-12 shadow-inner scale-110"><Check size={80} /></div>
                 <h2 className={`text-5xl font-black mb-5 ${isDarkMode ? 'text-white' : 'text-blue-900'}`}>{t.serviceFinished}</h2>
                 <p className="text-slate-400 font-bold mb-14 text-xl leading-relaxed">{t.ratingDesc}</p>
                 <div className="flex gap-4 mb-20">
                    {[1,2,3,4,5].map(s => (
                      <button key={s} onClick={() => setRating(s)} className={`p-3 transition-all transform hover:scale-125 ${s <= rating ? 'text-yellow-400' : 'text-slate-200'}`}><Star size={60} fill={s <= rating ? "currentColor" : "none"} /></button>
                    ))}
                 </div>
                 <button onClick={() => setActiveRequest(null)} className="w-full max-w-md py-7 bg-blue-900 text-white font-black rounded-[32px] text-2xl shadow-2xl active:scale-95 transition-all">{t.returnToNego}</button>
              </div>
            )}
         </div>
       )}
    </div>
  );
};

export default App;
