
import React from 'react';
import { Droplets } from 'lucide-react';
import { COLORS } from '../constants';

export const Logo: React.FC<{ size?: number, className?: string }> = ({ size = 32, className = "" }) => {
  return (
    <div className={`flex flex-row items-center gap-2 ${className}`}>
        <div className="relative flex-shrink-0">
            <Droplets size={size} color={COLORS.accent} fill={COLORS.accent} className="drop-shadow-sm" />
            <div className="absolute -bottom-0.5 -right-0.5 bg-yellow-400 rounded-full p-0.5 border border-white">
                 <div className="w-1.5 h-1.5 bg-blue-900 rounded-full"></div>
            </div>
        </div>
        <h1 className="text-2xl font-black text-blue-900 tracking-tighter leading-none">
            Wash<span className="text-yellow-500">Drive</span>
        </h1>
    </div>
  );
};
