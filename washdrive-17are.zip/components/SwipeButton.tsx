
import React, { useState, useRef, useEffect } from 'react';
import { ChevronRight } from 'lucide-react';

interface SwipeButtonProps {
  onSuccess: () => void;
  text: string;
  className?: string;
}

export const SwipeButton: React.FC<SwipeButtonProps> = ({ onSuccess, text, className = "" }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragWidth, setDragWidth] = useState(50); // Initial button width
  const containerRef = useRef<HTMLDivElement>(null);
  const [completed, setCompleted] = useState(false);

  const handleStart = (e: React.MouseEvent | React.TouchEvent) => {
    if (completed) return;
    setIsDragging(true);
  };

  const handleMove = (e: MouseEvent | TouchEvent) => {
    if (!isDragging || !containerRef.current || completed) return;

    const containerRect = containerRef.current.getBoundingClientRect();
    let clientX;
    
    if ('touches' in e) {
        clientX = e.touches[0].clientX;
    } else {
        clientX = (e as MouseEvent).clientX;
    }

    const offsetX = clientX - containerRect.left;
    const maxDrag = containerRect.width;
    
    // Constrain drag
    const newWidth = Math.max(50, Math.min(offsetX, maxDrag));
    setDragWidth(newWidth);

    // Check completion threshold (90%)
    if (newWidth >= maxDrag * 0.9) {
        setCompleted(true);
        setIsDragging(false);
        setDragWidth(maxDrag);
        onSuccess();
    }
  };

  const handleEnd = () => {
    if (completed) return;
    setIsDragging(false);
    // Reset if not completed
    setDragWidth(50);
  };

  useEffect(() => {
    if (isDragging) {
        window.addEventListener('mousemove', handleMove);
        window.addEventListener('mouseup', handleEnd);
        window.addEventListener('touchmove', handleMove);
        window.addEventListener('touchend', handleEnd);
    } else {
        window.removeEventListener('mousemove', handleMove);
        window.removeEventListener('mouseup', handleEnd);
        window.removeEventListener('touchmove', handleMove);
        window.removeEventListener('touchend', handleEnd);
    }
    return () => {
        window.removeEventListener('mousemove', handleMove);
        window.removeEventListener('mouseup', handleEnd);
        window.removeEventListener('touchmove', handleMove);
        window.removeEventListener('touchend', handleEnd);
    };
  }, [isDragging]);

  return (
    <div 
        ref={containerRef}
        className={`relative h-14 bg-slate-100 rounded-full overflow-hidden select-none shadow-inner border border-slate-200 ${className}`}
    >
        {/* Background Text */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <span className="text-slate-400 font-bold uppercase tracking-wider text-sm animate-pulse">{text}</span>
        </div>

        {/* Draggable Handle */}
        <div 
            className="absolute top-0 left-0 bottom-0 bg-green-500 rounded-full flex items-center justify-end pr-4 cursor-pointer active:cursor-grabbing transition-all duration-75 ease-linear shadow-lg"
            style={{ width: `${dragWidth}px` }}
            onMouseDown={handleStart}
            onTouchStart={handleStart}
        >
             <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm">
                <ChevronRight className={`text-green-600 ${completed ? 'opacity-0' : 'opacity-100'}`} />
             </div>
        </div>
    </div>
  );
};
