import React, { useEffect, useRef, useState } from 'react';
import { Layers, Navigation, Plus, Minus, Loader2, Compass } from 'lucide-react';
import { TRANSLATIONS } from '../constants';

interface MapBackgroundProps {
  showWashers?: boolean;
  userLocation?: { lat: number; lng: number; accuracy?: number } | null;
  language?: string;
}

export const MapBackground: React.FC<MapBackgroundProps> = ({ 
  showWashers = true, 
  userLocation,
  language = 'fr'
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const userMarkerRef = useRef<any>(null);
  const accuracyCircleRef = useRef<any>(null);
  const tileLayerRef = useRef<any>(null);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isSatellite, setIsSatellite] = useState(false);
  const [isGoogle, setIsGoogle] = useState(false);
  const [followUser, setFollowUser] = useState(true);
  const markersRef = useRef<any[]>([]);

  const t = TRANSLATIONS[language] || TRANSLATIONS['fr'];

  // 1. Initialisation de la carte
  useEffect(() => {
    const initMap = (useGoogle: boolean) => {
      if (!mapContainerRef.current || mapInstanceRef.current) return;
      
      const center = userLocation || { lat: 33.5883, lng: -7.6114 };
      setIsGoogle(useGoogle);

      if (useGoogle && (window as any).google?.maps) {
        mapInstanceRef.current = new (window as any).google.maps.Map(mapContainerRef.current, {
          center,
          zoom: 16,
          disableDefaultUI: true,
          mapTypeId: isSatellite ? 'satellite' : 'roadmap',
          styles: [
            { featureType: "poi", stylers: [{ visibility: "off" }] },
            { featureType: "transit", stylers: [{ visibility: "off" }] },
            { featureType: "road", elementType: "labels.icon", stylers: [{ visibility: "off" }] }
          ]
        });
        setIsLoading(false);
      } else if ((window as any).L) {
        const L = (window as any).L;
        const map = L.map(mapContainerRef.current, { 
          zoomControl: false, 
          attributionControl: false 
        }).setView([center.lat, center.lng], 16);
        
        tileLayerRef.current = L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png').addTo(map);
        mapInstanceRef.current = map;
        setTimeout(() => { map.invalidateSize(); setIsLoading(false); }, 400);
      }
    };

    if ((window as any).googleMapsReady) {
      initMap(true);
    } else {
      window.addEventListener('google-maps-loaded', () => initMap(true));
      window.addEventListener('google-maps-failed', () => initMap(false));
      const timer = setTimeout(() => { if (!mapInstanceRef.current) initMap(false); }, 3000);
      return () => clearTimeout(timer);
    }
  }, []);

  // 2. Gestion du suivi utilisateur et des marqueurs de précision
  useEffect(() => {
    if (!mapInstanceRef.current || !userLocation) return;

    const google = (window as any).google;
    const L = (window as any).L;

    // Recentrage automatique si activé
    if (followUser) {
      if (isGoogle) mapInstanceRef.current.panTo(userLocation);
      else mapInstanceRef.current.panTo([userLocation.lat, userLocation.lng]);
    }

    if (isGoogle && google?.maps) {
      // Marqueur utilisateur Google
      if (!userMarkerRef.current) {
        userMarkerRef.current = new google.maps.OverlayView();
        userMarkerRef.current.onAdd = function() {
          const div = document.createElement('div');
          div.className = 'user-location-container';
          div.innerHTML = '<div class="user-pulse"></div><div class="user-dot"></div>';
          this.getPanes().overlayMouseTarget.appendChild(div);
          this.div = div;
        };
        userMarkerRef.current.draw = function() {
          const projection = this.getProjection();
          if (!projection) return;
          const pos = projection.fromLatLngToDivPixel(new google.maps.LatLng(userLocation.lat, userLocation.lng));
          if (this.div) {
            this.div.style.left = pos.x + 'px';
            this.div.style.top = pos.y + 'px';
          }
        };
        userMarkerRef.current.setMap(mapInstanceRef.current);
      } else {
        userMarkerRef.current.draw();
      }

      // Cercle de précision Google
      if (userLocation.accuracy) {
        if (!accuracyCircleRef.current) {
          accuracyCircleRef.current = new google.maps.Circle({
            strokeColor: "#3b82f6",
            strokeOpacity: 0.3,
            strokeWeight: 1,
            fillColor: "#3b82f6",
            fillOpacity: 0.1,
            map: mapInstanceRef.current,
            center: userLocation,
            radius: userLocation.accuracy
          });
        } else {
          accuracyCircleRef.current.setCenter(userLocation);
          accuracyCircleRef.current.setRadius(userLocation.accuracy);
        }
      }
    } else if (L) {
      // Leaflet
      if (!userMarkerRef.current) {
        const icon = L.divIcon({ 
          className: '', 
          html: '<div class="user-location-container"><div class="user-pulse"></div><div class="user-dot"></div></div>',
          iconSize: [20, 20], iconAnchor: [10, 10] 
        });
        userMarkerRef.current = L.marker([userLocation.lat, userLocation.lng], { icon }).addTo(mapInstanceRef.current);
      } else {
        userMarkerRef.current.setLatLng([userLocation.lat, userLocation.lng]);
      }

      if (userLocation.accuracy) {
        if (!accuracyCircleRef.current) {
          accuracyCircleRef.current = L.circle([userLocation.lat, userLocation.lng], {
            radius: userLocation.accuracy,
            color: '#3b82f6',
            weight: 1,
            opacity: 0.3,
            fillColor: '#3b82f6',
            fillOpacity: 0.1
          }).addTo(mapInstanceRef.current);
        } else {
          accuracyCircleRef.current.setLatLng([userLocation.lat, userLocation.lng]);
          accuracyCircleRef.current.setRadius(userLocation.accuracy);
        }
      }
    }
  }, [userLocation, isGoogle, isLoading, followUser]);

  // 3. Marqueurs Laveurs avec Branding WashDrive
  useEffect(() => {
    if (!mapInstanceRef.current || !showWashers || !userLocation || isLoading) return;
    
    markersRef.current.forEach(m => m.setMap ? m.setMap(null) : m.remove());
    markersRef.current = [];

    const mockWashers = Array.from({ length: 8 }).map(() => ({
      lat: userLocation.lat + (Math.random() - 0.5) * 0.025,
      lng: userLocation.lng + (Math.random() - 0.5) * 0.025,
      dist: (0.2 + Math.random() * 3).toFixed(1),
      time: Math.floor(2 + Math.random() * 15)
    }));

    mockWashers.forEach(w => {
      const vanLogoHtml = `
        <div style="display:flex; flex-direction:column; align-items:center; filter: drop-shadow(0 8px 16px rgba(0,0,0,0.3)); transform-origin: bottom center; animation: float ${4 + Math.random()}s ease-in-out infinite;">
          <div style="background:white; padding:4px 12px; border-radius:14px; font-size:11px; font-weight:900; color:#172554; border:2.5px solid #FACC15; white-space:nowrap; margin-bottom:5px; box-shadow: 0 4px 6px rgba(0,0,0,0.15);">
            ${w.dist}km • ${w.time}min
          </div>
          <div style="position:relative; width:52px; height:52px; display:flex; align-items:center; justify-content:center;">
             <svg width="52" height="52" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="2" y="6" width="16" height="12" rx="3" fill="#FACC15" stroke="#172554" stroke-width="1.8"/>
                <path d="M18 8L23 11V18H18V8Z" fill="#172554" stroke="#172554" stroke-width="1.8"/>
                <circle cx="6" cy="18" r="2.5" fill="#172554" stroke="white" stroke-width="1"/>
                <circle cx="15" cy="18" r="2.5" fill="#172554" stroke="white" stroke-width="1"/>
                <rect x="4" y="8" width="8" height="4" rx="1.5" fill="#38BDF8"/>
                <circle cx="19" cy="8" r="4.5" fill="white" stroke="#38BDF8" stroke-width="1.2"/>
                <path d="M19 6.5C19 6.5 17.5 8 17.5 9C17.5 9.8 18.2 10.5 19 10.5C19.8 10.5 20.5 9.8 20.5 9C20.5 8 19 6.5 19 6.5Z" fill="#38BDF8"/>
             </svg>
          </div>
        </div>`;

      if (isGoogle) {
        const marker = new (window as any).google.maps.Marker({
          position: { lat: w.lat, lng: w.lng },
          map: mapInstanceRef.current,
          icon: { 
            url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(vanLogoHtml),
            scaledSize: new (window as any).google.maps.Size(80, 90),
            anchor: new (window as any).google.maps.Point(40, 90)
          }
        });
        markersRef.current.push(marker);
      } else {
        const icon = (window as any).L.divIcon({ html: vanLogoHtml, className: '', iconSize: [80, 90], iconAnchor: [40, 90] });
        const marker = (window as any).L.marker([w.lat, w.lng], { icon }).addTo(mapInstanceRef.current);
        markersRef.current.push(marker);
      }
    });
  }, [showWashers, userLocation, isLoading, isGoogle]);

  return (
    <div className="fixed inset-0 z-0 bg-slate-50">
      <div ref={mapContainerRef} className="absolute inset-0 w-full h-full" />
      
      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/95 backdrop-blur-2xl z-[100]">
           <div className="relative mb-10">
              <Loader2 className="w-24 h-24 text-blue-900 animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                 <div className="w-5 h-5 bg-yellow-400 rounded-full animate-ping"></div>
              </div>
           </div>
           <p className="font-black text-blue-900 text-lg tracking-widest uppercase animate-pulse">{t.navLive}</p>
        </div>
      )}

      {!isLoading && (
        <div className="fixed right-6 top-1/2 -translate-y-1/2 z-[100] flex flex-col gap-5 pointer-events-auto">
          {/* Toggle Satellite */}
          <button 
            onClick={() => setIsSatellite(!isSatellite)}
            className={`w-14 h-14 rounded-2xl shadow-2xl flex items-center justify-center border-2 transition-all active:scale-90 ${isSatellite ? 'bg-blue-900 text-white border-blue-700' : 'bg-white text-blue-900 border-white'}`}
          >
            <Layers size={28} />
          </button>
          
          {/* Zoom Controls */}
          <div className="flex flex-col bg-white rounded-3xl shadow-2xl border-2 border-white overflow-hidden">
            <button 
              onClick={() => isGoogle ? mapInstanceRef.current.setZoom(mapInstanceRef.current.getZoom() + 1) : mapInstanceRef.current.zoomIn()}
              className="w-14 h-14 flex items-center justify-center text-blue-900 active:bg-slate-100 border-b border-slate-100"
            >
              <Plus size={28} />
            </button>
            <button 
              onClick={() => isGoogle ? mapInstanceRef.current.setZoom(mapInstanceRef.current.getZoom() - 1) : mapInstanceRef.current.zoomOut()}
              className="w-14 h-14 flex items-center justify-center text-blue-900 active:bg-slate-100"
            >
              <Minus size={28} />
            </button>
          </div>

          {/* Auto-Follow Toggle / Re-center */}
          <button 
            onClick={() => {
                setFollowUser(!followUser);
                if (userLocation) {
                    if (isGoogle) mapInstanceRef.current.panTo(userLocation);
                    else mapInstanceRef.current.panTo([userLocation.lat, userLocation.lng]);
                }
            }}
            className={`w-14 h-14 rounded-2xl shadow-2xl flex items-center justify-center border-2 transition-all active:scale-90 ${followUser ? 'bg-blue-600 text-white border-blue-400' : 'bg-white text-slate-400 border-white'}`}
          >
            <Navigation size={28} fill={followUser ? "currentColor" : "none"} className={followUser ? "animate-pulse" : ""} />
          </button>
        </div>
      )}
    </div>
  );
};