export type Language = string;

export type UserRole = 'client' | 'washer' | null;

export type VehicleType = 'moto_coffre' | 'van_wash';

export interface User {
  id: string;
  phoneNumber: string;
  role: UserRole;
  name: string;
  countryCode: string;
  walletBalance: number;
  servicesCompleted: number;
  isVerified: boolean; 
  vehicleType?: VehicleType;
}

export type ServiceType = 'external' | 'complete' | 'premium';

export interface WasherOffer {
  id: string;
  washerName: string;
  rating: number;
  price: number;
  distance: string;
  eta: string;
  vehicleType: VehicleType;
}

export interface ServiceRequest {
  id: string;
  clientName: string;
  pickupLocation: string;
  coordinates: { lat: number; lng: number };
  priceOffer: number;
  serviceType: ServiceType;
  status: 'searching' | 'negotiating' | 'accepted' | 'in_progress' | 'completed' | 'rating';
  offers: WasherOffer[];
}

export interface CountryCode {
  code: string;
  name: string;
  dialCode: string;
  flag: string;
  currency: string;
  basePrice: number;
  paymentMethod: string;
}